use redis::Commands;
use s_orm::pool::pool::{create_db_pool};
use sea_orm::entity::prelude::*;
use s_orm::entity::{users, users::Entity as UserEntity};
use axum::{
    routing::get,
    http::StatusCode,
    extract::{Query, Json},
    extract::State,
    Router,
};
use res::Response;
use std::sync::Arc;
use r2d2;
use redis_r2d2::RedisConnectionManager;
#[derive(Clone)]
pub struct AppState {
    pub db: DatabaseConnection,
    pub redis_pool: r2d2::Pool<RedisConnectionManager>,
}
#[tokio::main]
async fn main() {
    let manage = RedisConnectionManager::new("redis://192.168.16.136:6379/").unwrap();
    let redis_pool = r2d2::Pool::builder().max_size(15).build(manage).unwrap();
    //let app_state = create_db_pool().unwrap();】
    let db = create_db_pool().await;
    let app_state = AppState {
        db: db.clone(),
        redis_pool: redis_pool.clone(),
    };
    let app: Router = Router::new().route("/", get(index)).route("/test", get(index1)).with_state(Arc::new(app_state.clone()));
    //let app: Router = Router::new().route("/", get(index)).with_state(Arc::new(app_state.clone()));
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn index(State(app_state): State<Arc<AppState>>) ->  Result<Json<Response<Vec<users::Model>>>, (StatusCode, String)>  {
    let data: Result<Vec<users::Model>, DbErr> = get_users(&app_state.db).await;
    match data {
        Ok(datas) => {
            Ok(Json(Response::new(1, datas)))
        }
        Err(e) => {
            // 返回一个适当的错误响应
            Err((StatusCode::INTERNAL_SERVER_ERROR, format!("Error: {:?}", e)))
        }
    }
    // String::from("Hello, World!")
}
#[derive(serde::Deserialize,Debug)]
struct MessageData {
    #[serde(default="default_message")]
    message: String
}
fn default_message() -> String {
    "default".to_string()
}
async fn index1(State(app_state): State<Arc<AppState>>, Query(req): Query<MessageData>) ->  Result<Json<Response<Vec<users::Model>>>, (StatusCode, String)>  {
    println!("{:?}", req.message);
    let data: Result<Vec<users::Model>, DbErr> = get_users1(&app_state.db).await;
    //let ret = &app_state.redis_pool.get().unwrap().set::<&str, &str, ()>("key", &req.message).unwrap();
    let mut conn = app_state.redis_pool.get().unwrap();
    // 执行 Redis 命令
    let _: () = conn.set::<&str, &str, ()>("key", &req.message).unwrap();
    match data {
        Ok(datas) => {
            Ok(Json(Response::new(2, datas)))
        }
        Err(e) => {
            // 返回一个适当的错误响应
            Err((StatusCode::INTERNAL_SERVER_ERROR, format!("Error1: {:?}", e)))
        }
    }
    // String::from("Hello, World!")
}

async fn get_users(db:&DatabaseConnection) -> Result<Vec<users::Model>, DbErr> {
    let users:Vec<users::Model> = UserEntity::find().all(db).await.unwrap(); 
    Ok(users)
}

async fn get_users1(db:&DatabaseConnection) -> Result<Vec<users::Model>, DbErr> {
    let users:Vec<users::Model> = UserEntity::find().all(db).await.unwrap();
    
    Ok(users)
}