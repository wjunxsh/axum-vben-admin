use std::env;
use axum::{response::{Html, IntoResponse}, Error};
use dotenv::dotenv;
use axum::{
    routing::get,
    routing::post,
    Router,
};
use sea_orm::Database;
use sea_orm::entity::*;
use s_orm::entity::users::{Model};
#[tokio::main]
async fn main() {
    dotenv().ok(); // 加载 .env 文件中的环境变量
    // build our application with a single route
    let app = Router::new().route("/", get(|| async { "Hello, World!" }))
        .route("/index", get(index1))
        .route("/index1", get(|| async { "Hello, World!2" }))
        .route("/index2", post(|| async { "Hello, World!3" }));

    // run our app with hyper, listening globally on port 3000
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}


async fn index1() -> Result<Vec<Model>, Box<dyn std::error::Error>> {
    dotenv().ok();  // 加载 .env 文件中的环境变量
    let data = getUser().await;
    match data {
        Ok(data) => {
            Ok(data)
        }
        Err(e) => {
            Err(Box::new(e))
        }
    }
}

async fn getUser() -> Result<vec<Model>, Box<dyn std::error::Error>> {
    dotenv().ok();  // 加载 .env 文件中的环境变量
    let db_url = env::var("DATABASE_URL").expect("DATABASE_URL is not set in .env file");
    let db = Database::connect(&db_url).await.unwrap();
    let users: Vec<Model> = Model::find().all(&db).await.unwrap();
    Ok(users)
}